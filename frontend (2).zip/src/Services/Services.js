import { axiosService } from "./Helper";

export const signIn = async (userData) => {
  return axiosService
    .post("/api/auth/login", userData, { headers: { "Content-Type": "application/json" } })
    .then((response) => response.data);
};

export const signUp = async (userData) => {
  return axiosService
    .post("/api/auth/register", userData, { headers: { "Content-Type": "application/json" } })
    .then((response) => response.data);
};

export const createBlog = async (postDto, userId, categoryId) => {
  return axiosService
    .post(`/api/user/${userId}/category/${categoryId}/posts`, postDto, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
  })
    .then((response) => response.data);
};


export const getAllCategories = async () => {
  return axiosService.get("/api/categories/").then((response) => response.data);
}

export const getUserById = async (userId) => {
  return axiosService.get(`/api/users/${userId}`).then((response) => response.data);
}

export const getAllPosts = async (pageNumber = 0, pageSize = 10, sortBy = "postId") => {
  return axiosService.get("/api/posts", {
    params: {
      pageNumber,
      pageSize,
      sortBy
    }
  }).then((response) => response.data);
}

export const getAllJobs = () => {
  return axiosService.get("/api/jobs/jobPosts").then((response) => response.data);
}

export const getAllNews = () => {
  return axiosService.get("/api/news/").then((response) => response.data);
}

export const getBlogById = (postId) => {
  return axiosService.get(`/api/posts/${postId}`).then((response) => response.data);
}

export const addComment = (comment, postId, userId) => {
  return axiosService
    .post(`/api/comments/post/${postId}/user/${userId}/comments`, { "content": comment }, {
      headers: {
        "Content-Type": "application/json",
      },
    })
    .then((response) => response.data);
}