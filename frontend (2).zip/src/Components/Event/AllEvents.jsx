import React from 'react'
import NavBar from '../NavBar'

const AllEvents = () => {
  return (
    <div>
        <NavBar />
      <h1>All Events</h1>
    </div>
  )
}

export default AllEvents
